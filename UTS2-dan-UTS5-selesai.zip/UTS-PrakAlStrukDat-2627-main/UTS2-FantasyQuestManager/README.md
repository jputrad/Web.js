# 🏰 Fantasy Quest Manager

Aplikasi web sederhana berbasis Python dan Streamlit untuk mengelola misi petualangan (_quest_) di dunia fantasi Eldoria. Kamu berperan sebagai pengelola Guild Adventurer yang mencatat quest, memantau statusnya, dan menghitung total estimasi waktu.

Materi yang diintegrasikan: **Rekursif**, **Struktur Data Built-in Python**, dan **Manajemen State Streamlit**.

Jalankan program dengan `streamlit run app.py`.

## 🧙 Data Quest

| Atribut        | Keterangan                            |
| -------------- | ------------------------------------- |
| `id`           | Nomor identitas quest                 |
| `nama`         | Nama misi                             |
| `role`         | Role petualang yang bertanggung jawab |
| `prioritas`    | Rendah, Sedang, atau Tinggi           |
| `estimasi_jam` | Estimasi waktu penyelesaian (jam)     |
| `selesai`      | Status penyelesaian (`True`/`False`)  |

Pilihan role petualang: **Fighter, Assassin, Archer, Mage, Tank**.

## ⚔️ Spesifikasi Fitur

### 1. Login

- Halaman login muncul lebih dulu; isi aplikasi hanya tampil setelah login berhasil.
- Dua akun, password sama:

| Akun         | Password |
| ------------ | -------- |
| `adventurer` | `123`    |
| `guild`      | `123`    |

- Jika Username/Password salah → tampilkan pesan error.
- Status login disimpan di `st.session_state`, dan tersedia tombol **Logout**.
- Hak akses:

| Fitur                                   | guild | adventurer |
| --------------------------------------- | :---: | :--------: |
| Melihat Quest Board, Report, Calculator |  ✅   |     ✅     |
| Menambah quest                          |  ✅   |     ❌     |
| Menandai quest selesai / belum selesai  |  ✅   |     ❌     |
| Menghapus quest                         |  ✅   |     ❌     |

Akun `adventurer` hanya dapat melihat; form tambah, checkbox status, dan tombol hapus tidak boleh ditampilkan untuknya.

### 2. Inisialisasi Data

Siapkan penyimpanan quest di `st.session_state` tanpa menimpa data yang sudah ada saat rerun.

### 3. Tambah Quest

Form berisi nama, role, prioritas, dan estimasi jam. Nama tidak boleh kosong, estimasi harus bilangan bulat positif, dan setiap quest memiliki ID unik.

### 4. Quest Board

Tampilkan daftar quest lengkap. Akun `guild` dapat menandai selesai, membatalkan status selesai, dan menghapus quest; akun `adventurer` hanya melihat daftar. Setiap perubahan harus langsung tercermin pada data dan Guild Report.

### 5. Filter dan Guild Report

Filter: Semua Quest, Quest Aktif, Quest Selesai. Report menampilkan total quest, jumlah aktif, jumlah selesai, dan total estimasi waktu.

### 6. Recursive Adventure Calculator

Fungsi rekursif (dengan _base case_ dan _recursive case_) untuk menghitung total estimasi jam seluruh quest. Tidak boleh memakai `sum()` atau perulangan di dalam fungsi tersebut. Daftar kosong menghasilkan `0`.

## 📊 Rubrik Penilaian

| Komponen                     |    Poin |
| ---------------------------- | ------: |
| Login, logout & hak akses    |      15 |
| Inisialisasi & struktur data |      10 |
| Tambah & hapus quest         |      15 |
| Quest Board                  |      20 |
| Filter & Guild Report        |      20 |
| Fungsi rekursif              |      20 |
| **Total**                    | **100** |

Penilaian didasarkan pada ketercapaian fungsi, bukan kompleksitas kode atau dekorasi visual.
