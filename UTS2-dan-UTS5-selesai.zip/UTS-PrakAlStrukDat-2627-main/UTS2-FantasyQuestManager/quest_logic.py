def tambah_quest(daftar_quest, nama, role, prioritas, estimasi_jam):
    """Menambah quest. Mengembalikan pesan error, atau None jika berhasil."""
    if not isinstance(nama, str) or not nama.strip():
        return "Nama quest tidak boleh kosong."

    if isinstance(estimasi_jam, bool) or not isinstance(estimasi_jam, int) or estimasi_jam <= 0:
        return "Estimasi waktu harus berupa bilangan bulat positif."

    if daftar_quest:
        id_baru = max(quest["id"] for quest in daftar_quest) + 1
    else:
        id_baru = 1

    daftar_quest.append({
        "id": id_baru,
        "nama": nama.strip(),
        "role": role,
        "prioritas": prioritas,
        "estimasi_jam": estimasi_jam,
        "selesai": False,
    })
    return None

def filter_quest(daftar_quest, status):
    if status == "Quest Aktif":
        return [quest for quest in daftar_quest if not quest["selesai"]]
    if status == "Quest Selesai":
        return [quest for quest in daftar_quest if quest["selesai"]]
    return list(daftar_quest)

def hitung_total_jam(daftar_quest, index=0):
    """Total estimasi jam secara rekursif (tanpa sum() atau perulangan)."""
    if index >= len(daftar_quest):
        return 0
    return daftar_quest[index]["estimasi_jam"] + hitung_total_jam(daftar_quest, index + 1)
