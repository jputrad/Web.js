import streamlit as st
from config import AKUN, APP_ICON, APP_TITLE

def sudah_login():
    return st.session_state.akun_login is not None

def logout():
    st.session_state.akun_login = None

def tampilkan_login():
    st.title(f"{APP_ICON} {APP_TITLE}")

    with st.form("form_login"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        masuk = st.form_submit_button("Login")

    if masuk:
        username = username.strip().lower()
        if username in AKUN and AKUN[username] == password:
            st.session_state.akun_login = username
            st.rerun()
        else:
            st.error("Username atau password salah.")

def tampilkan_info_akun():
    with st.sidebar:
        st.write(f"Akun aktif: **{st.session_state.akun_login}**")
        st.button("Logout", on_click=logout)
