import streamlit as st

from auth import sudah_login, tampilkan_info_akun, tampilkan_login
from config import APP_ICON, APP_TITLE, FILTER_OPTIONS, PRIORITAS_OPTIONS, ROLES
from quest_logic import filter_quest, hitung_total_jam, tambah_quest
from state import init_state

st.set_page_config(page_title=APP_TITLE, page_icon=APP_ICON, layout="wide")
init_state()

if not sudah_login():
    tampilkan_login()
    st.stop()

tampilkan_info_akun()
quests = st.session_state.quests

is_guild = st.session_state.akun_login == "guild"

st.title(f"{APP_ICON} {APP_TITLE}")
st.divider()

# ---------- Form tambah quest (hanya guild) ----------
if is_guild:
    st.subheader("📜 Daftarkan Quest Baru")
    with st.form("form_tambah_quest", clear_on_submit=True):
        nama = st.text_input("Nama quest")
        role = st.selectbox("Role petualang", options=ROLES)
        prioritas = st.selectbox("Prioritas quest", options=PRIORITAS_OPTIONS)
        jam = st.number_input("Estimasi waktu (jam)", min_value=1, step=1)
        kirim = st.form_submit_button("➕ Tambahkan Quest")

    # Tangkap ketika tombol kirim ditekan, panggil fungsi tambah_quest,
    # tampilkan error jika ada atau success jika berhasil.
    if kirim:
        pesan_error = tambah_quest(quests, nama, role, prioritas, jam)
        if pesan_error:
            st.error(pesan_error)
        else:
            st.success("Quest berhasil ditambahkan.")
            st.rerun()

    st.divider()

area_report = st.container()
st.divider()

# ---------- Quest Board ----------
st.subheader("🧭 Quest Board")
if not is_guild:
    st.caption("Akun adventurer hanya dapat melihat Quest Board.")
filter_status = st.selectbox("Tampilkan quest", options=FILTER_OPTIONS)
daftar = filter_quest(quests, filter_status)

if not daftar:
    st.info("Belum ada quest yang sesuai dengan filter ini.")

for quest in daftar:
    with st.container(border=True):
        kolom_info, kolom_status, kolom_hapus = st.columns([5, 2, 1])

        kolom_info.markdown(f"**#{quest['id']} — {quest['nama']}**")
        kolom_info.write(
            f"Role: {quest['role']} · Prioritas: {quest['prioritas']} · "
            f"Estimasi: {quest['estimasi_jam']} jam"
        )

        if is_guild:
            status_baru = kolom_status.checkbox(
                "Selesai", value=quest["selesai"], key=f"selesai_{quest['id']}"
            )
            if status_baru != quest["selesai"]:
                quest["selesai"] = status_baru
                st.rerun()

            if kolom_hapus.button("🗑️", key=f"hapus_{quest['id']}"):
                st.session_state.quests = [
                    item for item in st.session_state.quests if item["id"] != quest["id"]
                ]
                st.rerun()
        else:
            kolom_status.write("✅ Selesai" if quest["selesai"] else "⚔️ Aktif")

# ---------- Guild Report ----------
total = len(quests)
selesai = sum(1 for quest in quests if quest["selesai"])

with area_report:
    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Total Quest", total)
    k2.metric("Quest Aktif", total - selesai)
    k3.metric("Quest Selesai", selesai)
    k4.metric("Total Estimasi", f"{hitung_total_jam(quests)} jam")

st.divider()

# ---------- Recursive Adventure Calculator ----------
st.subheader("🔮 Recursive Adventure Calculator")
st.metric("Total waktu seluruh petualangan", f"{hitung_total_jam(quests)} jam")
