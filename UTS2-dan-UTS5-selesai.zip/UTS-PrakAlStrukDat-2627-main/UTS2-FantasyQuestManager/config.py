APP_TITLE = "Fantasy Quest Manager"
APP_ICON = "🏰"

ROLES = ("Fighter", "Assassin", "Archer", "Mage", "Tank")
PRIORITAS_OPTIONS = ("Rendah", "Sedang", "Tinggi")
FILTER_OPTIONS = ("Semua Quest", "Quest Aktif", "Quest Selesai")

# Akun login: nama akun -> password.
AKUN = {
    "adventurer": "123",
    "guild": "123",
}
