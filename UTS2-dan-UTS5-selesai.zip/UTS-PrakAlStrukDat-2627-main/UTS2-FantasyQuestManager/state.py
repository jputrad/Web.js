import streamlit as st

def init_state():
    # Inisialisasi daftar quest hanya jika belum tersedia.
    if "quests" not in st.session_state:
        st.session_state.quests = []

    # Inisialisasi akun login hanya jika belum tersedia.
    if "akun_login" not in st.session_state:
        st.session_state.akun_login = None
