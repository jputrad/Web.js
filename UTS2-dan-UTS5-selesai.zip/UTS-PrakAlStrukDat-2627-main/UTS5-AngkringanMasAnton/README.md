# UTS Praktikum Algoritma dan Struktur Data
## Angkringan Digital "Mas Anton" di Bawah Fly Over Lempuyangan

### Cerita

Di bawah **Fly Over Lempuyangan**, tidak jauh dari Stasiun Lempuyangan, berdiri angkringan **Mas Anton**. Gerobaknya ramai sejak sore: penumpang yang menunggu kereta, driver ojol yang mampir ngopi, sampai mahasiswa yang nongkrong sambil menonton kereta lewat di atas kepala.

Belakangan Mas Anton kewalahan. Saat kereta lewat dan suasana bising, pesanan sering salah dengar. Catatan di kertas bungkus gorengan hilang tertiup angin, dan stok bakmi jawa tiba-tiba habis padahal masih tercatat ada.

Adiknya, **Kevin**, mahasiswa Informatika, berencana membuat **halaman Etalase berbasis Streamlit** agar pembeli bisa melihat menu, memfilter kategori, dan mengurutkan menu. Sayangnya, Kevin harus berangkat KKN besok pagi, sehingga **3 fungsi pengolah data** dan **tampilan Streamlit**-nya belum sempat ia tulis.

Tugas Anda: lengkapi ketiga fungsi tersebut dan buat tampilan Etalase-nya agar angkringan siap buka nanti sore.

| Bagian halaman | Fungsi yang dipakai |
|---|---|
| **Etalase**: tabel menu, filter kategori, tombol Balik Urutan | `buat_inventori`, `kategori_unik`, `sort_menu`, `main` |

---

### Struktur File

```
Soal UTS Angkringan Mas Anton/
├── README.md   <- soal (file ini)
├── app.py      <- TEMPLATE: kerjakan di sini
└── test.py     <- test case untuk menguji app.py
```

### Aturan Pengerjaan

1. Kerjakan **hanya** di `app.py`, pada bagian yang bertanda `# TODO`.
2. **Jangan mengubah** nama fungsi, parameter, `MENU_AWAL`, maupun fungsi bantu `daftar_menu()`.
3. Boleh menambah fungsi bantu sendiri. Tidak boleh meng-*import* library tambahan.
4. Syarat khusus (jika dilanggar, **nilai soal tersebut menjadi 0**):
   - **Soal 2**: wajib memakai `set`.
   - **Soal 3**: dilarang memakai `sorted()` dan `.sort()`.

### Data Awal

```python
# Tuple of tuple: (kode, nama, kategori, harga, stok)
MENU_AWAL = (
    ("ANG01", "Nasi Kucing",      "Makanan",  3000, 40),
    ("ANG02", "Sate Usus",        "Lauk",     2500, 50),
    ("ANG03", "Sate Telur Puyuh", "Lauk",     4000, 30),
    ("ANG04", "Gorengan Tempe",   "Lauk",     1500, 60),
    ("ANG05", "Wedang Jahe",      "Minuman",  5000, 25),
    ("ANG06", "Kopi Joss",        "Minuman",  6000, 20),
    ("ANG07", "Es Teh Manis",     "Minuman",  4000, 35),
    ("ANG08", "Bakmi Jawa",       "Makanan", 15000, 12),
)
```

---

## Soal

### Soal 1 – `buat_inventori(data_menu)` · **20 poin**

Daftar menu Mas Anton disimpan dalam **tuple**. Aplikasi membutuhkan **dictionary** agar menu bisa dicari langsung berdasarkan kodenya.

| Parameter | Tipe | Keterangan |
|---|---|---|
| `data_menu` | `tuple` | Tuple berisi tuple `(kode, nama, kategori, harga, stok)` |

**Return:** `dict` dengan *key* kode menu dan *value* dictionary detail.

```python
>>> buat_inventori((("ANG01", "Nasi Kucing", "Makanan", 3000, 40),))
{"ANG01": {"nama": "Nasi Kucing", "kategori": "Makanan", "harga": 3000, "stok": 40}}

>>> buat_inventori(())
{}
```

---

### Soal 2 – `kategori_unik(inventori)` · **20 poin**

Filter kategori di Etalase membutuhkan daftar kategori yang **tidak dobel**.

| Parameter | Tipe | Keterangan |
|---|---|---|
| `inventori` | `dict` | Hasil `buat_inventori()` |

**Return:** `list` kategori unik yang **terurut A–Z**. Wajib memakai `set`; `sorted()` boleh dipakai di soal ini.

```python
>>> kategori_unik(buat_inventori(MENU_AWAL))
["Lauk", "Makanan", "Minuman"]

>>> kategori_unik({})
[]
```

---

### Soal 3 – `sort_menu(daftar, kunci, menurun=False)` · **30 poin**

Tabel Etalase bisa diurutkan berdasarkan kode, harga, stok, atau nama. Tombol **Balik Urutan** membalik arah: Naik (`menurun=False`) menjadi Turun (`menurun=True`), dan sebaliknya.

| Parameter | Tipe | Keterangan |
|---|---|---|
| `daftar` | `list` | List of dict menu, misal `[{"kode": "ANG01", "nama": ..., "harga": ..., ...}, ...]` |
| `kunci` | `str` | Key dasar pengurutan: `"kode"`, `"harga"`, `"stok"`, atau `"nama"` |
| `menurun` | `bool` | `False` (default) = kecil→besar / A–Z; `True` = besar→kecil / Z–A |

**Return:** `list` **baru** yang sudah terurut. List asli tidak boleh berubah.

> **Syarat:**
> - Boleh memakai **merge sort** atau **quick sort**.
> - Dilarang memakai `sorted()` / `.sort()`.
> - Hasil harus **stabil**: jika dua data memiliki nilai `kunci` yang sama, urutan aslinya dipertahankan (berlaku juga saat `menurun=True`). Untuk quick sort, gunakan versi yang membagi data ke list baru (`kecil`, `sama`, `besar`) sambil mempertahankan urutan; quick sort *in-place* (tukar posisi) tidak stabil.

```python
>>> menu = [{"kode": "A", "harga": 4000}, {"kode": "B", "harga": 1500},
...         {"kode": "C", "harga": 4000}, {"kode": "D", "harga": 6000}]
>>> [d["kode"] for d in sort_menu(menu, "harga")]
["B", "A", "C", "D"]
>>> [d["kode"] for d in sort_menu(menu, "harga", menurun=True)]
["D", "A", "C", "B"]        # A tetap sebelum C (stabil)
```

---

### Soal 4 – Tampilan Etalase di `main()` · **30 poin**

Di dalam `main()` sudah tersedia `inventori = buat_inventori(MENU_AWAL)` dan fungsi bantu `daftar_menu(inventori)` yang mengubah inventori menjadi list of dict (dengan key `"kode"`). Lanjutkan `main()` sehingga halaman menampilkan:

| No | Komponen | Ketentuan |
|---|---|---|
| a | `st.title` | Teks judul memuat **`Angkringan Mas Anton`** |
| b | `st.session_state["menurun"]` | Dibuat dengan nilai awal `False` **hanya jika belum ada** (supaya tidak ter-reset saat rerun) |
| c | `st.selectbox("Kategori", ...)` | Pilihan: `["Semua"]` + hasil `kategori_unik(inventori)` |
| | `st.selectbox("Urutkan berdasarkan", ...)` | Pilihan: `["kode", "harga", "stok", "nama"]` |
| d | **Satu** `st.button` **Balik Urutan** | Label memuat kata `Balik`. Setiap diklik, `menurun` dibalik: `False` → `True`, `True` → `False` |
| e | `st.table(data)` | `data` = hasil `sort_menu(daftar_menu(inventori), kunci, menurun)`, lalu **jika** kategori bukan `"Semua"`, sisakan menu dengan kategori tersebut |

Contoh tampilan:

```
Angkringan Mas Anton
Etalase
Kategori
┌──────────────────────────┐
│ Minuman                ▼ │
└──────────────────────────┘
Urutkan berdasarkan
┌──────────────────────────┐
│ harga                  ▼ │
└──────────────────────────┘
[Balik Urutan]
Arah urutan: Turun
 kode   nama          kategori  harga  stok
 ANG06  Kopi Joss     Minuman    6000    20
 ANG05  Wedang Jahe   Minuman    5000    25
 ANG07  Es Teh Manis  Minuman    4000    35      <- setelah tombol Balik Urutan diklik 1x
```

> Label `selectbox` harus **persis** seperti di tabel, karena aplikasi diuji otomatis dengan `streamlit.testing`. Komponen disusun berurutan dari atas ke bawah (tanpa `st.columns`); teks tambahan/header bebas.

---

## Menjalankan dan Menguji

```bash
pip install streamlit      # atau: uv add streamlit
streamlit run app.py       # jalankan aplikasi
python test.py             # uji jawaban + rekap nilai (termasuk tampilan Streamlit)
python test.py -v          # detail setiap test case
```

## Penilaian

| Soal | Fungsi | Poin |
|---|---|---|
| 1 | `buat_inventori` | 20 |
| 2 | `kategori_unik` | 20 |
| 3 | `sort_menu` | 30 |
| 4 | `main` (Etalase) | 30 |
| | **Total** | **100** |

- Nilai tiap soal = poin × (jumlah test lulus / jumlah test soal tersebut).
- Test Soal 4 menjalankan aplikasi Anda, sehingga tabelnya baru benar jika Soal 1–3 juga benar.
- Jika **syarat** suatu soal dilanggar, nilai soal tersebut menjadi **0** walaupun hasilnya benar.
- Asisten dapat menguji ulang dengan test case tambahan, jadi jangan menulis jawaban yang hanya menyesuaikan contoh (*hard-code*).

**Selamat mengerjakan, semoga angkringan Mas Anton laris manis!**
