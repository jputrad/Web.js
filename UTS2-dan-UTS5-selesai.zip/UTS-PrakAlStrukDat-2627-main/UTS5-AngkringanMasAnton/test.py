"""
Test case UTS Praktikum Algoritma dan Struktur Data
Studi Kasus : Angkringan Digital "Mas Anton"

Cara pakai:
    python test.py            -> menguji app.py (jawaban mahasiswa)
    python test.py jawaban    -> menguji jawaban.py (kunci jawaban)
    python test.py -v         -> tampilkan detail setiap test

Catatan penilaian:
    - Nilai tiap soal = POIN x (test lulus / jumlah test soal tsb).
    - Test di daftar SYARAT tidak menambah nilai, tetapi jika GAGAL
      maka nilai soal tersebut menjadi 0 (wajib set, dilarang
      sorted()/.sort()).
    - Soal 4 (Streamlit) diuji dengan streamlit.testing.v1.AppTest.
"""

import ast
import copy
import importlib
import inspect
import sys
import textwrap
import unittest

# ---------------------------------------------------------------------
# Pilih modul yang diuji
# ---------------------------------------------------------------------
NAMA_MODUL = "app"
for _arg in sys.argv[1:]:
    if not _arg.startswith("-"):
        NAMA_MODUL = _arg.replace(".py", "")
        sys.argv.remove(_arg)
        break

m = importlib.import_module(NAMA_MODUL)

MENU_UJI = (
    ("ANG01", "Nasi Kucing", "Makanan", 3000, 40),
    ("ANG02", "Sate Usus", "Lauk", 2500, 50),
    ("ANG03", "Sate Telur Puyuh", "Lauk", 4000, 30),
    ("ANG04", "Gorengan Tempe", "Lauk", 1500, 60),
    ("ANG05", "Wedang Jahe", "Minuman", 5000, 25),
    ("ANG06", "Kopi Joss", "Minuman", 6000, 20),
    ("ANG07", "Es Teh Manis", "Minuman", 4000, 35),
    ("ANG08", "Bakmi Jawa", "Makanan", 15000, 12),
)


def inventori_baru():
    return {
        kode: {"nama": n, "kategori": k, "harga": h, "stok": s}
        for kode, n, k, h, s in MENU_UJI
    }


def ast_fungsi(fungsi):
    return ast.parse(textwrap.dedent(inspect.getsource(fungsi)))


def larangan_sort_bawaan(fungsi):
    """Cari pemakaian sorted() / .sort() di fungsi dan fungsi bantu yang dipanggilnya."""
    diperiksa, antrean, pelanggaran = set(), [fungsi.__name__], []
    while antrean:
        nama = antrean.pop()
        if nama in diperiksa or not inspect.isfunction(getattr(m, nama, None)):
            continue
        diperiksa.add(nama)
        for node in ast.walk(ast_fungsi(getattr(m, nama))):
            if isinstance(node, ast.Call):
                if isinstance(node.func, ast.Attribute) and node.func.attr == "sort":
                    pelanggaran.append(f"{nama}: .sort()")
                if isinstance(node.func, ast.Name):
                    if node.func.id == "sorted":
                        pelanggaran.append(f"{nama}: sorted()")
                    antrean.append(node.func.id)
    return pelanggaran


# =====================================================================
# SOAL 1 - buat_inventori (20 poin)
# =====================================================================
class Soal1_BuatInventori(unittest.TestCase):
    POIN = 20

    def test_tipe_dan_jumlah(self):
        inv = m.buat_inventori(MENU_UJI)
        self.assertIsInstance(inv, dict)
        self.assertEqual(len(inv), 8)

    def test_isi_lengkap(self):
        self.assertEqual(m.buat_inventori(MENU_UJI), inventori_baru())

    def test_data_lain_dan_kosong(self):
        data = (("X1", "Tahu Bacem", "Lauk", 2000, 7),)
        self.assertEqual(
            m.buat_inventori(data),
            {"X1": {"nama": "Tahu Bacem", "kategori": "Lauk", "harga": 2000, "stok": 7}},
        )
        self.assertEqual(m.buat_inventori(()), {})


# =====================================================================
# SOAL 2 - kategori_unik (20 poin)
# =====================================================================
class Soal2_KategoriUnik(unittest.TestCase):
    POIN = 20
    SYARAT = ["test_memakai_set"]

    def test_kategori_menu_awal(self):
        self.assertEqual(m.kategori_unik(inventori_baru()), ["Lauk", "Makanan", "Minuman"])

    def test_tanpa_duplikat_dan_kosong(self):
        inv = {
            "A": {"nama": "a", "kategori": "Snack", "harga": 1, "stok": 1},
            "B": {"nama": "b", "kategori": "Snack", "harga": 1, "stok": 1},
            "C": {"nama": "c", "kategori": "Jajanan", "harga": 1, "stok": 1},
        }
        self.assertEqual(m.kategori_unik(inv), ["Jajanan", "Snack"])
        self.assertEqual(m.kategori_unik({}), [])

    def test_memakai_set(self):
        pohon = ast_fungsi(m.kategori_unik)
        pakai_set = any(
            isinstance(n, (ast.Set, ast.SetComp))
            or (isinstance(n, ast.Call) and getattr(n.func, "id", None) == "set")
            for n in ast.walk(pohon)
        )
        self.assertTrue(pakai_set, "kategori_unik wajib memakai struktur data set")


# =====================================================================
# SOAL 3 - sort_menu (30 poin)
# =====================================================================
class Soal3_SortMenu(unittest.TestCase):
    POIN = 30
    SYARAT = ["test_tanpa_sort_bawaan"]

    def setUp(self):
        self.daftar = [{"kode": k, **v} for k, v in inventori_baru().items()]

    def kode(self, hasil):
        return [d["kode"] for d in hasil]

    def test_tanpa_sort_bawaan(self):
        self.assertEqual(larangan_sort_bawaan(m.sort_menu), [],
                         "Dilarang memakai sorted() / .sort(), implementasikan algoritmanya")

    def test_harga_naik(self):
        hasil = m.sort_menu(self.daftar, "harga")
        self.assertEqual(self.kode(hasil),
                         ["ANG04", "ANG02", "ANG01", "ANG03", "ANG07", "ANG05", "ANG06", "ANG08"])

    def test_harga_turun_stabil(self):
        hasil = m.sort_menu(self.daftar, "harga", menurun=True)
        # ANG03 & ANG07 sama-sama 4000 -> urutan asal dipertahankan
        self.assertEqual(self.kode(hasil),
                         ["ANG08", "ANG06", "ANG05", "ANG03", "ANG07", "ANG01", "ANG02", "ANG04"])

    def test_nama_naik(self):
        hasil = m.sort_menu(self.daftar, "nama")
        self.assertEqual([d["nama"] for d in hasil],
                         ["Bakmi Jawa", "Es Teh Manis", "Gorengan Tempe", "Kopi Joss",
                          "Nasi Kucing", "Sate Telur Puyuh", "Sate Usus", "Wedang Jahe"])

    def test_kategori_stabil(self):
        hasil = m.sort_menu(self.daftar, "kategori")
        self.assertEqual(self.kode(hasil),
                         ["ANG02", "ANG03", "ANG04", "ANG01", "ANG08", "ANG05", "ANG06", "ANG07"])

    def test_stok_turun(self):
        hasil = m.sort_menu(self.daftar, "stok", True)
        self.assertEqual([d["stok"] for d in hasil], [60, 50, 40, 35, 30, 25, 20, 12])

    def test_list_asli_tidak_berubah(self):
        salinan = copy.deepcopy(self.daftar)
        hasil = m.sort_menu(self.daftar, "harga")
        self.assertEqual(self.kode(hasil)[0], "ANG04")
        self.assertEqual(self.daftar, salinan)

    def test_kecil(self):
        self.assertEqual(m.sort_menu([{"harga": 2}, {"harga": 1}], "harga"),
                         [{"harga": 1}, {"harga": 2}])
        self.assertEqual(m.sort_menu([], "harga"), [])
        self.assertEqual(m.sort_menu([{"harga": 1}], "harga"), [{"harga": 1}])


# =====================================================================
# SOAL 4 - Tampilan Etalase Streamlit (30 poin)
# =====================================================================
class Soal4_TampilanEtalase(unittest.TestCase):
    POIN = 30

    def setUp(self):
        from streamlit.testing.v1 import AppTest
        self.at = AppTest.from_file(m.__file__, default_timeout=10).run()
        self.assertFalse(self.at.exception, "Aplikasi error saat dijalankan")

    def selectbox(self, label):
        for s in self.at.selectbox:
            if s.label.strip().lower() == label.lower():
                return s
        self.fail(f'st.selectbox "{label}" tidak ditemukan')

    def tombol(self, kata):
        for b in self.at.button:
            if kata.lower() in b.label.lower():
                return b
        self.fail(f'st.button "{kata}" tidak ditemukan')

    def tabel(self):
        if len(self.at.table):
            return self.at.table[0].value
        if len(self.at.dataframe):
            return self.at.dataframe[0].value
        self.fail("st.table tidak ditemukan")

    def test_judul(self):
        judul = " ".join(t.value for t in self.at.title)
        self.assertIn("Angkringan Mas Anton", judul)

    def test_selectbox_kategori(self):
        self.assertEqual(list(self.selectbox("Kategori").options),
                         ["Semua", "Lauk", "Makanan", "Minuman"])

    def test_selectbox_urutan(self):
        self.assertEqual(list(self.selectbox("Urutkan berdasarkan").options),
                         ["kode", "harga", "stok", "nama"])

    def test_session_state_tombol(self):
        self.assertIs(self.at.session_state["menurun"], False)
        self.tombol("Balik").click().run()
        self.assertIs(self.at.session_state["menurun"], True)
        self.tombol("Balik").click().run()
        self.assertIs(self.at.session_state["menurun"], False)

    def test_tabel_semua_menu(self):
        tabel = self.tabel()
        self.assertEqual(len(tabel), 8)
        self.assertEqual(list(tabel["kode"]), [f"ANG0{i}" for i in range(1, 9)])

    def test_tabel_urut_turun(self):
        self.selectbox("Urutkan berdasarkan").set_value("harga").run()
        self.tombol("Balik").click().run()
        self.assertEqual(list(self.tabel()["kode"]),
                         ["ANG08", "ANG06", "ANG05", "ANG03", "ANG07", "ANG01", "ANG02", "ANG04"])

    def test_tabel_filter_kategori(self):
        self.selectbox("Kategori").set_value("Minuman").run()
        self.selectbox("Urutkan berdasarkan").set_value("stok").run()
        self.assertEqual(list(self.tabel()["kode"]), ["ANG06", "ANG05", "ANG07"])


# =====================================================================
# Runner + rekap nilai
# =====================================================================
class HasilBernilai(unittest.TextTestResult):
    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.lulus = []

    def addSuccess(self, test):
        super().addSuccess(test)
        self.lulus.append(test)


def main():
    loader = unittest.TestLoader()
    kelas_soal = [
        Soal1_BuatInventori, Soal2_KategoriUnik, Soal3_SortMenu,
        Soal4_TampilanEtalase,
    ]
    suite = unittest.TestSuite(loader.loadTestsFromTestCase(k) for k in kelas_soal)
    verbosity = 2 if "-v" in sys.argv else 1
    hasil = unittest.TextTestRunner(resultclass=HasilBernilai, verbosity=verbosity).run(suite)

    lulus_ids = {t.id() for t in hasil.lulus}
    print("\n" + "=" * 52)
    print(f" REKAP NILAI  (modul: {NAMA_MODUL}.py)")
    print("=" * 52)
    total = 0.0
    for k in kelas_soal:
        syarat = getattr(k, "SYARAT", [])
        semua = [t.id() for t in loader.loadTestsFromTestCase(k)
                 if t.id().rsplit(".", 1)[-1] not in syarat]
        ok = sum(1 for t in semua if t in lulus_ids)
        syarat_gagal = [s for s in syarat if f"{__name__}.{k.__name__}.{s}" not in lulus_ids]
        nilai = 0.0 if syarat_gagal else k.POIN * ok / len(semua)
        total += nilai
        catatan = "  <- SYARAT GAGAL: " + ", ".join(syarat_gagal) if syarat_gagal else ""
        print(f" {k.__name__:<24} {ok:>2}/{len(semua):<2} test  {nilai:5.1f} / {k.POIN}{catatan}")
    print("-" * 52)
    print(f" NILAI AKHIR{'':<25}{total:6.1f} / 100")
    print("=" * 52)
    return 0 if hasil.wasSuccessful() else 1


if __name__ == "__main__":
    sys.exit(main())
