"""
Petunjuk:
- Lengkapi semua bagian bertanda TODO (Soal 1-4, lihat README.md).
- JANGAN mengubah nama fungsi, parameter, data awal, dan fungsi daftar_menu().
- Boleh menambah fungsi bantu sendiri.

Jalankan : streamlit run app.py
"""

import streamlit as st

# =====================================================================
# DATA AWAL (JANGAN DIUBAH)
# =====================================================================

# Tuple of tuple: (kode, nama, kategori, harga, stok)
MENU_AWAL = (
    ("ANG01", "Nasi Kucing", "Makanan", 3000, 40),
    ("ANG02", "Sate Usus", "Lauk", 2500, 50),
    ("ANG03", "Sate Telur Puyuh", "Lauk", 4000, 30),
    ("ANG04", "Gorengan Tempe", "Lauk", 1500, 60),
    ("ANG05", "Wedang Jahe", "Minuman", 5000, 25),
    ("ANG06", "Kopi Joss", "Minuman", 6000, 20),
    ("ANG07", "Es Teh Manis", "Minuman", 4000, 35),
    ("ANG08", "Bakmi Jawa", "Makanan", 15000, 12),
)


# =====================================================================
# SOAL 1 - buat_inventori  (Tuple -> Dictionary)              [20 poin]
# =====================================================================
def buat_inventori(data_menu):
    """
    Mengubah tuple MENU_AWAL menjadi dictionary inventori.

    Parameter:
        data_menu (tuple): tuple berisi tuple (kode, nama, kategori, harga, stok)

    Return:
        dict: {kode: {"nama": ..., "kategori": ..., "harga": ..., "stok": ...}}
    """
    inventori = {}
    for kode, nama, kategori, harga, stok in data_menu:
        inventori[kode] = {
            "nama": nama,
            "kategori": kategori,
            "harga": harga,
            "stok": stok,
        }
    return inventori


# =====================================================================
# SOAL 2 - kategori_unik  (Set)                               [20 poin]
# =====================================================================
def kategori_unik(inventori):
    """
    Mengambil semua kategori unik dari inventori.

    Parameter:
        inventori (dict): hasil buat_inventori()

    Return:
        list: kategori unik, terurut A-Z (boleh memakai sorted())
    """
    kategori = set()
    for item in inventori.values():
        kategori.add(item["kategori"])
    return sorted(kategori)


# =====================================================================
# SOAL 3 - sort_menu  (Merge Sort / Quick Sort)              [30 poin]
# =====================================================================
def sort_menu(daftar, kunci, menurun=False):
    """
    Mengurutkan daftar menu berdasarkan kunci tertentu memakai MERGE SORT
    atau QUICK SORT.
    DILARANG memakai sorted() / .sort(). Hasil harus STABIL.

    Parameter:
        daftar  (list): list of dict menu
        kunci   (str) : "kode", "harga", "stok", atau "nama"
        menurun (bool): False = kecil->besar (A-Z), True = besar->kecil (Z-A)

    Return:
        list: list baru yang sudah terurut (list asli tidak boleh berubah)
    """
    data = list(daftar)
    if len(data) <= 1:
        return data

    tengah = len(data) // 2
    kiri = sort_menu(data[:tengah], kunci, menurun)
    kanan = sort_menu(data[tengah:], kunci, menurun)

    hasil = []
    i = 0
    j = 0

    while i < len(kiri) and j < len(kanan):
        nilai_kiri = kiri[i][kunci]
        nilai_kanan = kanan[j][kunci]

        if menurun:
            ambil_kiri = nilai_kiri >= nilai_kanan
        else:
            ambil_kiri = nilai_kiri <= nilai_kanan

        if ambil_kiri:
            hasil.append(kiri[i])
            i += 1
        else:
            hasil.append(kanan[j])
            j += 1

    hasil.extend(kiri[i:])
    hasil.extend(kanan[j:])
    return hasil


# =====================================================================
# SOAL 4 - Tampilan Etalase  (Streamlit + session_state)      [30 poin]
# =====================================================================
def daftar_menu(inventori):
    """(SUDAH JADI) Ubah inventori (dict) menjadi list of dict yang memiliki key 'kode'."""
    return [{"kode": k, **v} for k, v in inventori.items()]


def main():
    st.set_page_config(page_title="Angkringan Mas Anton")
    inventori = buat_inventori(MENU_AWAL)

    st.title("Angkringan Mas Anton")
    if "menurun" not in st.session_state:
        st.session_state["menurun"] = False

    kategori_pilihan = st.selectbox(
        "Kategori", ["Semua"] + kategori_unik(inventori)
    )
    kunci = st.selectbox(
        "Urutkan berdasarkan", ["kode", "harga", "stok", "nama"]
    )

    if st.button("Balik Urutan"):
        st.session_state["menurun"] = not st.session_state["menurun"]

    st.write(f"Arah urutan: {'Turun' if st.session_state['menurun'] else 'Naik'}")

    data = sort_menu(daftar_menu(inventori), kunci, st.session_state["menurun"])
    if kategori_pilihan != "Semua":
        data = [item for item in data if item["kategori"] == kategori_pilihan]

    st.table(data)


if __name__ == "__main__":
    main()
